#!/usr/bin/env bash
# Self-signed cert for HTTPS/WSS. Usage: ./gen_certs.sh [LAN_IP]
set -e
cd "$(dirname "$0")/certs"
SAN="DNS:localhost,IP:127.0.0.1"
[ -n "$1" ] && SAN="$SAN,IP:$1"
openssl req -x509 -newkey rsa:2048 -nodes -days 365 \
  -keyout key.pem -out cert.pem -subj "/CN=localhost" -addext "subjectAltName=$SAN"
echo "Created certs/cert.pem and certs/key.pem"
